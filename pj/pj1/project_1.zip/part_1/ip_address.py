
import dpkt
import socket
import datetime
from collections import defaultdict

out_f = open("ip_timestamps.txt", "w")

def count_proto(pcap_file):
    # read the pcap file
    f = open(pcap_file, 'rb')
    pcap = dpkt.pcap.Reader(f)

    ip_address = defaultdict(list)

    # iterate over packets
    for timestamp, data in pcap:

        # convert to link layer object
        eth = dpkt.ethernet.Ethernet(data)

        # do not proceed if there is no network layer data
        if not isinstance(eth.data, dpkt.ip.IP):
            continue
        
        # extract network layer data
        ip = eth.data
        
        #print(socket.inet_ntoa(ip.dst))
        ip_address[socket.inet_ntoa(ip.dst)].append(datetime.datetime.utcfromtimestamp(timestamp))

        #print timestamps
        #print(datetime.datetime.utcfromtimestamp(timestamp))
    
    for ip, tstamps in ip_address.items():
        i = 1
        print(f"\nIPV4: {ip}\n")
        out_f.write(f"\nIPV4: {ip}\n\n")
        for time in tstamps:
            print(f"timestamp#{i}: {time}")
            out_f.write(f"timestamp#{i}: {time}\n")
            i+=1



# main
for i in range(1, 7):
    
    num = str(i)
    file = "_activity.pcap"
    pcap_file =  num + file
    print(f"\nLoading file: {pcap_file}\n")
    out_f.write(f"\nLoading file: {pcap_file}\n")
    count_proto(pcap_file)

    
    