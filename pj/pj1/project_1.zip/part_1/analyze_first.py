
import dpkt
from collections import defaultdict

# Part 1a q1

# This function count the occurence of each port used in each one of the activity.
def count_port(pcap_file):
    # read the pcap file
    f = open(pcap_file, 'rb')
    pcap = dpkt.pcap.Reader(f)

    protocol_count = defaultdict(int)

    # iterate over packets
    for timestamp, data in pcap:

        # convert to link layer object
        eth = dpkt.ethernet.Ethernet(data)

        # do not proceed if there is no network layer data
        if not isinstance(eth.data, dpkt.ip.IP) and not isinstance(eth.data, dpkt.ip6.IP6):
            continue
        
        # extract network layer data
        ip = eth.data
        #print(ip)

        # do not proceed if there is no transport layer data
        if isinstance(ip.data, dpkt.tcp.TCP):
            

            # extract transport layer data
            tcp = ip.data

            # do not proceed if there is no application layer data
            # here we check length because we don't know protocol yet
            if not len(tcp.data) > 0:
                continue

            src = tcp.sport
            dst = tcp.dport

            # increament each protocol count by 1

            protocol_count[src] += 1
            protocol_count[dst] += 1

            # extract application layer data
            ## if destination port is 80, it is a http request

            #print(f"TCP src={tcp.sport}, dst={tcp.dport}")

            
        elif isinstance(ip.data, dpkt.udp.UDP):

            # extract transport layer data
            udp = ip.data

            # do not proceed if there is no application layer data
            # here we check length because we don't know protocol yet
            if not len(udp.data) > 0:
                continue

            src = udp.sport
            dst = udp.dport

            # increament each protocol count by 1

            protocol_count[src] += 1
            protocol_count[dst] += 1

        else:
            continue

    # sort by increasing port number
    sorted_protocol = sorted(protocol_count.items())

    # print out the port along with its frequency
    for port, count in sorted_protocol:
        print(f"port = {port}, count = {count}")



# main
for i in range(1, 7):
    
    num = str(i)
    file = "_activity.pcap"
    pcap_file =  num + file
    print(f"\nLoading file: {pcap_file}\n")
    count_port(pcap_file)
    
    