import dpkt

# Part 1b q1

f = open("PCAP1_1.pcap", 'rb')
pcap = dpkt.pcap.Reader(f)

# iterate over packets
for timestamp, data in pcap:

    # convert to link layer object
    eth = dpkt.ethernet.Ethernet(data)

    # do not proceed if there is no network layer data
    if not isinstance(eth.data, dpkt.ip.IP) and not isinstance(eth.data, dpkt.ip6.IP6):
        continue
    
    # extract network layer data
    ip = eth.data

    # do not proceed if there is no transport layer data
    if not isinstance(ip.data, dpkt.tcp.TCP):
        continue

    # extract transport layer data
    tcp = ip.data

    # do not proceed if there is no application layer data
    # here we check length because we don't know protocol yet
    if not len(tcp.data) > 0:
        continue

    # extract application layer data
    ## if destination port is 80, it is a http request
    if tcp.dport == 80:
        try:
            http = dpkt.http.Request(tcp.data)
            print(f"The secret is: {http.headers["my-secret"]}")
        except:
            pass
            
    ## if source port is 80, it is a http response
    elif tcp.sport == 80:
        try:
            http = dpkt.http.Response(tcp.data)
            print(f"The secret is: {http.headers["my-secret"]}")
        except:
            pass